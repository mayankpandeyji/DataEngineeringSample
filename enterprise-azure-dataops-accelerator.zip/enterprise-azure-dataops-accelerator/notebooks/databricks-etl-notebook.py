
# Databricks notebook source
# COMMAND ----------
df = spark.read.parquet("/mnt/blob/input-data/")
df_transformed = df.withColumnRenamed("old_column", "new_column")
df_transformed.write.format("delta").mode("overwrite").save("/mnt/adls/processed-data/")
