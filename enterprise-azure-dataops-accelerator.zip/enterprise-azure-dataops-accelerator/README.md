
# Enterprise Azure DataOps Accelerator

## Overview
A modular reference solution for enterprise data ingestion using Azure Data Factory, Databricks, and Delta Lake.

## Stack
- Azure Data Factory
- Azure Databricks
- Azure Bicep
- Azure DevOps CI/CD
- SonarQube, Snyk, Wiz integration

## Pipeline Flow
1. `.parquet` files ingested from Azure Blob
2. ADF triggers Databricks notebook for transformation
3. Data stored as Delta Lake in ADLS Gen2

## Security
- Code quality via SonarQube
- Dependency security with Snyk
- Cloud posture management using Wiz
